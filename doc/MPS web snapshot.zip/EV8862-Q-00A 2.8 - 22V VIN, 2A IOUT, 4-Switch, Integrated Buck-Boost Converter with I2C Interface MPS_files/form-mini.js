define(['jquery'],function($){'use strict';function isEmpty(value){return(value.length===0)||(value==null)||/^\s+$/.test(value);}
return function(widget){$.widget('mage.quickSearch',widget,{_onSubmit:function(e){var value=this.element.val();if(isEmpty(value)){if(typeof e==='undefined'){return false;}
e.preventDefault();}
if(this.responseList.selected){this.element.val(this.responseList.selected.find('.qs-option-name').text());}}});return $.mage.quickSearch;}});