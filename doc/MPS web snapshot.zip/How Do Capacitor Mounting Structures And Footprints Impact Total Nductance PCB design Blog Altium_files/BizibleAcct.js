(function () {
    BizTrackingA.GoAccount({
        webToLeadField: '',
        chatEnabled: 'true' === 'true',
        XUserId: '7b64f98beb4a4fcb8ab23ade30813dd3',
        formProviderEnabled: 'true' === 'true',
        attach_secure_forms: 'true' === 'true',
        viewThroughEnabled: 'false' === 'true',
        interceptAjax: 'true' === 'true'
    });
})();
;
