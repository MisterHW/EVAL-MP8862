(function ($) {

  $=jQuery;

  function tmHide() {
    $('.topmenu-item').hide();
    $('#menutag').hide();
    $('.topmenu ul li a').removeClass('active');
  }

  var tmActive = 0;

  $(document).ready(function () {
    $('#topmenu-products').find('a[href$="products/downloads"]').attr({onclick:"_gaq.push(['_trackEvent', 'downloads', 'productnav', 'downloads']);"});
    $('#topmenu-products').find('a[href$="how-to-buy"]').attr({onclick:"_gaq.push(['_trackEvent', 'howtobuy', 'productnav', 'downloads']);"});
    $('#topmenu-solutions').find('a[href$="altium-designer/overview"]').attr({onclick:"_gaq.push(['_trackEvent', 'AD15', 'solutionsnav', 'AD15']);"});
    $('#topmenu-solutions').find('a[href$="altium-vault/overview"]').attr({onclick:"_gaq.push(['_trackEvent', 'AV', 'solutionsnav', 'AV']);"});
    $('#topmenu-solutions').find('a[href$="subscription/overview"]').attr({onclick:"_gaq.push(['_trackEvent', 'Subscription', 'solutionsnav', 'subscription']);"});

    var tmItems = $('.topmenu ul li a');
    tmItems.click(function () {
      if (tmItems.index(this) != tmActive) {
        tmHide();
      }
      tmActive = tmItems.index(this);
      submenu = this.id.replace("tm-", "#topmenu-");

      if ($("div").is(submenu)) {
        $(this).addClass('active');
        x = $(this).offset().left + ($(this).width() / 2) - 75;
        $('#menutag').css({left: x}).show();
        $(submenu).show();
      }
    });

    $('.menutag').click(function () {
      tmHide();
    });

    var tmProductsFilter = $('.tm-products-filter li');
    tmProductsFilter.click(function () {
      tmProductsFilter.removeClass("active");
      tmProductsFilterIndex = tmProductsFilter.index(this);
      tmProductsFilter.eq(tmProductsFilterIndex).addClass("active");
      if (tmProductsFilterIndex == 0) $('.tm-products-list li').show();
      if (tmProductsFilterIndex == 1) {
        $('.tm-products-list li').hide();
        $('.tm-products-list li.tm-pcb').show();
      }
      if (tmProductsFilterIndex == 2) {
        $('.tm-products-list li').hide();
        $('.tm-products-list li.tm-dm').show();
      }
      if (tmProductsFilterIndex == 3) {
        $('.tm-products-list li').hide();
        $('.tm-products-list li.tm-emb').show();
      }
      if (tmProductsFilterIndex == 4) {
        $('.tm-products-list li').hide();
        $('.tm-products-list li.tm-srv').show();
      }
    });
  });

  $(window).resize(function () {
    if( $('.topmenu').length ){
      x = $('.topmenu ul li a').eq(tmActive).offset().left + ($('.topmenu ul li a').eq(tmActive).width() / 2) - 75;
      $('#menutag').css({left: x});
    }
  });

  jQuery(document).click(function(event) {
    if ($(event.target).closest(".menu-solutions-ul-second-level-active").length) return;
    $("li").removeClass('menu-solutions-ul-second-level-active');
    event.stopPropagation();
  });

  jQuery(document).ready(function () {
    // jQuery('.front li.menu-solutions-li-first-level div.menu-solutions-div-first-level').click(function () {
    //   jQuery('#last-container-scroll').scrollTo('#carousel-bottom', {duration: 500});
    // });
    jQuery('li.menu-solutions-li-first-level div.menu-solutions-div-first-level').click(function () {
      jQuery("li").removeClass('menu-solutions-ul-second-level-active');
      jQuery(this).parent().parent().addClass('menu-solutions-ul-second-level-active');
    });
    jQuery('li.menu-solutions-li-first-level div.menu-solutions-div-first-level-main').hover(function () {

    },function () {
      jQuery(this).parent().removeClass('menu-solutions-ul-second-level-active');
    });

    jQuery('#block-menu-block-12 span.dropdown-toggle').click(function () {
      jQuery(this).parent().find('ul.dropdown-menu').animate({opacity: "show"}, 100);
    });
    jQuery('#block-menu-block-12 li.dropdown').hover(function () {
      jQuery(this).find('span.dropdown-toggle').addClass('active-trail');
    },function () {
      jQuery(this).find('span.dropdown-toggle').removeClass('active-trail');
      jQuery(this).find('ul.dropdown-menu').animate({opacity: "hide"}, 100);
    });
    jQuery('#block-menu-block-12 li.dropdown span.dropdown-toggle').hover(function () {
      jQuery(this).addClass('active-trail');
    },function () {
      jQuery(this).removeClass('active-trail');
    });
  });

  $(document).ready(function () {
    // if(!$('body').hasClass('old-menu-processed')) {
    //   $('body').addClass('old-menu-processed');
      initTopBarTel($('#block-altiumcommonheadermenu #ids-login-block'), 'after');
      initTopBarTel($('.site-header .container .menu'), 'before');
      createOldMenu();
      initSearchCollapsed();
    // }
  });

  function createOldMenu() {
    var $wrapper = $('#branding');
    var url = window.location.origin;
    // var url = ~window.location.origin.indexOf('demotest.altium.com') ? "https://demotest.altium.com" : "https://www.altium.com";

    updateAttr($wrapper.find('a'), 'href');
    updateAttr($wrapper.find('img'), 'src');
    updateAttr($('#fix-branding a'), 'href');
    updateAttr($('.footer a'), 'href');
    updateAttr($('.footer img'), 'src');

    function updateAttr(elms, currentAttr) {
      elms.each(function() {
        var $this = $(this);
        var attr = $this.attr(currentAttr);

        if(attr && !~attr.indexOf('http') && !~attr.indexOf('mailto') && !~attr.indexOf('tel')) {
          $this.attr(currentAttr, url + attr);
        }
      });
    }

    //create mobile menu
    var $levelFirst = $wrapper.find('.topmenu li a');
    var $secondLevel = $wrapper.find('.topmenu-item');
    var $thirdLevel = $wrapper.find('#subnavigation .nav');
    var $breadcrumbs = $wrapper.find('#subnavigation-breadcrumb li');

    $wrapper.find('> .container').append('<a class="btn-open btn-mobile--collapse" href="#"><span class="btn-mobile-box"><span class="btn-mobile-inner"></span></span></a>');
    $wrapper.find('> .asdf-container').append('<a class="btn-open btn-mobile--collapse" href="#"><span class="btn-mobile-box"><span class="btn-mobile-inner"></span></span></a>');
    $wrapper.find('.btn-open').on('click', function(e) {
      e.preventDefault();

      var $this = $(this);

      $this.toggleClass('active');
      $this.parent().siblings('.mobile-header').toggleClass('active');
    });

    var $mobileHeader = '<div class="mobile-header"><ul></ul></div>';
    $wrapper.append($mobileHeader);
    $mobileHeader = $wrapper.find('.mobile-header > ul');

    initTopBarTel($mobileHeader);

    $levelFirst.each(function() {
      var $this = $(this);
      var prefix = $this.attr('id') ? $this.attr('id').replace('tm-', '') : '' ;
      var $secondLevelElm = $secondLevel.filter('#topmenu-' + prefix);

      $mobileHeader.append('<li>' + ($this.parent().html() + ($secondLevelElm.length ? $secondLevelElm.html() : ''))  + '<span class="btn-close"></span></li>');
    });

    // if($breadcrumbs.first().text().trim().toLowerCase() == 'products') {
    //   $mobileHeader.parent().append(('<div class="title">' + $breadcrumbs.last().text().trim() + '</div>') + $thirdLevel.parent().html());
    // }

    var $btnClose = $mobileHeader.find('.btn-close');
    var $levelFirstMobile = $mobileHeader.find('> li > a');
    var $levelSecondMobile = $mobileHeader.find('> li > .topmenu-item-inner');

    $btnClose.on('click', hideAll);

    $levelFirstMobile.on('click', function(e) {
      var $this = $(this);
      var $thisNav = $this.siblings('.topmenu-item-inner');

      if($thisNav.length) {
        e.preventDefault();
        hideAll();
        $thisNav.addClass('active');
        $this.addClass('active');
      }

    });

    function hideAll() {
      $levelFirstMobile.removeClass('active');
      $levelSecondMobile.removeClass('active');
    }
  }

  function initSearchCollapsed() {
    var $wrapper = $('.topmenu'),
      $btnOpen = $wrapper.find('.btn-search'),
      $collapsedBlock = $wrapper.find('.b-search-collapsed'),
      $searchForm = $collapsedBlock.find('#search-block-form'),
      $field = $collapsedBlock.find('.form-search-collapsed .form-text'),
      $btnClose = $collapsedBlock.find('.btn-close'),
      $body = $('body');

    $btnOpen.on('click', checkSearch);
    $btnClose.on('click', checkSearch);

    $searchForm.submit(function(e) {
      e.preventDefault();
      window.open($searchForm.attr("action") + $field.val(),'_blank');
      $btnClose.click();
    });

    $field.keydown(function (e) {
      if (e.keyCode == 32) {
        $(this).val($(this).val() + " ");
        return false;
      }
    });

    $('html').on('click', function(e) {
      var $target = $(e.target);

      if(!$body.hasClass('search-active')) return;

      if(!$target.closest($collapsedBlock).length && !$target.hasClass('btn-search')) {
        removeActive();
      } else if($target.closest($collapsedBlock).length && !$target.hasClass('btn-close')) {
        $field.focus();
      }
    });

    function checkSearch(e) {
      e.preventDefault();

      if($body.hasClass('search-active')) {
        removeActive();
      } else {
        addActive();
      }
    }

    function removeActive() {
      $body.removeClass('search-active');
    }

    function addActive() {
      $body.addClass('search-active');
      $field.focus();
    }
  }

  function initTopBarTel(appendTo, position) {
    if($.cookie('ALU_LLR_2')) {
      return;
    }

    if(!position) {
      position = 'after';
    }

    var tels = undefined;
    if(typeof Drupal !== 'undefined' && Drupal.settings && Drupal.settings.altium_common_menus && Drupal.settings.altium_common_menus.regions_phone) {
      tels = Drupal.settings.altium_common_menus.regions_phone;
    } else if(typeof drupalSettings !== 'undefined' && drupalSettings.altium_common_menus && drupalSettings.altium_common_menus.regions_phone) {
      tels = drupalSettings.altium_common_menus.regions_phone;
    } else {
      return;
    }

    if(!tels) return;

    // if(typeof Drupal == 'undefined' || !Drupal.settings.altium_common_menus || !Drupal.settings.altium_common_menus.regions_phone) return;

    var $elm = $(appendTo);
    var imgs = [
      {
        code: 'CH',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MDUzRTI2Nzk0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MDUzRTI2N0E0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDowNTNFMjY3NzQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDowNTNFMjY3ODQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PteNdKQAAAc8SURBVHja1Fp7bFNVGD/nvtrbdV27des6B+wFQpARxmNEAohEgxiHf2hmeIoxEgIxEvAfFY0aIjExYiYJmiiIDLIEAsaofwGZoHEONkWRxzbGzNY9uq2Pu7577/We++huu3bsrmVuX3a7tl/vud/vnO/7fd95wJWLKwDggSQQCpf4J1xQ+FpW8Eg1qhO/Re9ltZnlChYy/nXzfIGVjwTD8wvCkVJTlM3XsVwW0odwzOclcKdTR3U69NTttiz6t5smw2UvQQyIzwRy+2LLijFA9b3KPPFnvGIWgGoAPJRugIqZsuEKEFEjN2hko3lPDHu3rx5mNpf5g0tlbBMW1HpnFn39aq7p9BWr+aSPJIbiAWCxX8YwCD0mda6qz0UAsnnKPxGAjDIGQAaTG2XtNQPDB54e9OzScVIPpyshDPM35pu//s5u/chF4Y44e9Q9nzA6SPDiwtw494m/dXREcMATNU73/jc7HWcXjgTWEjxPgQyJ0BZZ7gusWO907WIhjHYY6WbBG7hEN1K7U0xXXVkBIBavgHw8AHsoPHf//d6G0kBoCZgC6TLo//i8vGhLD637J64joeJSglfIHoLPsuVKwaBCqfg6ulZ4Rja9c6/np4JwtARMkZgj0cI1Q54dAoBbDlp3Ww0AjnEhAQAc4zhSHDw15Hnt9X/7TlIcT4MpFuSi1S7vi26S7OvM0l9XbAJxrAQlAPHRIkHZMOjZvat74BgcpYMpF/TsKvfIcx6SGOg0Gq4pJqrjIWYcr4ry5R5fzas9A3VgmsjLXX11VS6mRjJaMlyMAeHCRo2XzC8Ohhfs6+qrx3iBeKaJIFv2dPTUF/mDC5QcAYHqnfIBF+hsf1ffGT3HGcE0Ez3LGfe295zBeZYEAsOivkcXxqvSmMDzb5QEQovBNJXZ/uDiZ3pd+0ZzsQRDfJ8bjhbV9rveTfch/AOudOX5HudBS5gtEvOBcBFQ7v4XnK630nUdZCC1fDmgd+xIqg988w0INzdrK5qSuNKmHufbJ0pte0S6RS+mCGtdP+x9JRPDTFZWAsOePUl10dZWEUC6ssbp3nlulvU9hsAHxSBe62a2ZipZ8aHQpHRahOI4epXTsxWKDIUAuJitYIbJqkHPFpFGzVGuoCwQqpppAEp8waUWgXiwRYz/Sa2TkekgyOYFXt86Yp4/WD0ZtklJoeFw6vsEHT++UZqk1BdcRgilw3xteV3IfkYjgAQRm7XFDES1icWS+lZBh5vNYycmqL6PRgE/MiIkWW7CptgD4UdhC0W22cORion2PFFcDExHjwJ8zhzxoQkIAGa1Arwk+dSBvX8fcIODcSWxaL/QGWxXF/AK9Bvt7p7wSPTrqXbCHGVtmkaApgFZXQ0wm02z3yJgqcBhhYVi21okJxK1YTTHZWu6Sxhi3ufLeFCKbWpwHzkrZ2NgBksUwjAWwDBmpgII4hiDuUm8XysLwaysjBsjtolpcwgfgbuIPopst4cmxkJSSRkAkaamh8JCqG0t0qen2ohuHXV7CePfMMHsB1iHA7i3bUuZB+jaWmA6dix5jx0+DAINDePmAS3JrJem7hB3DfomrSzEeb0p8wTncqW+VdCxbndKI7VmYrTcQvyVTV/m5XVdDXVIah1FjauDIDOFF7L5ZrbxEuYm8P57tK5lpjHQ/Sx9i4siHOKcuNGSfWqmAfg1L+c0VFbdGs3Zp8IYDMwU45GtV/LNJ2MrcwxJDF60mI5nhM91uknptEij1XwczYcR6xEK/Z0tsBxa52K2p7syEblxA/iFajWVLgPZd+RCUf4hhU4IkcsFZxomCUeDzfLBjt6hj9OYJYmrDuOtPKTLQOeL8j9EwauwWVzu/t5qPiIwUmuaU71xr7SYx6Bv/bHQ8qkyJ+QTAbAQRj6ZY6/145h3OhZudRXFLyEbUVcoRcCY6slBEW1HZtu2cRCw08V4DkL2aFnx1l49dVc1+xZjV9qhSahNHHrqjgfHncsY/7PTAcDxEvveX6ym+mSRlBQAwCDoMOiuuUiidynj2/h/7dIgL/iqxL77YoH5i7ERJn2ObTHFgZD9q4PWXe+idTeqGP9Gkud1U+rzGDZSV168+WpeTj2EWMJizqitD+zZ33OMFw7Mm70sXXbSIl0G/Z8HF5RUN1uyzz+I8sQR4OU19mQ0h0ZGyHrDl/JMxyMYDM73Bx/HeUA+rBLhXFHB+8fKina6SaJv7DmKhBFQAACo3khOikJkgltG+srl3JwT6OclwXBlpnbr0VGDS/nmLz8rL65tNWf/gJ6VuJ2aCgCsXlSuig+VIu7chbKTPDpKpihrXevyblvtYraU+YNVkzrsYdC3XM0z1f+cl/MtQ5CDsQMDcnUQD0C95CLHRCIAZcc+7jQIAPGNJbgaOghiYTnbY0xg3Vx/oBrtchaEpOM2tFxXoYD0krhzgCI7u/XUrfYsuulvYSLlIYl+qX+glFUhltSFecCrj34AdS74T4ABAGCZ4h85Oi+1AAAAAElFTkSuQmCC',
      },
      {
        code: 'US',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MDUzRTI2N0Q0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MDUzRTI2N0U0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDowNTNFMjY3QjQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDowNTNFMjY3QzQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PiMOZpwAAAzoSURBVHja1FoLVJRVHv/f7/tmhmFmGN4MCCiICIlPTHAVFJ/lrs9K2lLU2ixTe508dnar3bXMk7tnq92y9JzNLM22DJUyzcpnISgIiMrwcgARecwwMO/3t/femW8Yqe2kB1r9wzfA5c53f////f0f9/sPum/GOAgUhBB+Id8oYND7g+d5YBim33wAD4iihw3PyJuYPTn72ImGtAvVHUkMK41yMBJZukkLizrVZpZxdPVIGE2vFKm7FFDSrmSO20TQSe5J1hQuQHgN3rdeAA7kw+bB8wV8ZIwTgPnB9wMtiLCQf0FGEmG0RRaY7FEPmaySzJiUUajyMoL2LhHwoAC3hweH1Q7yUakwZuNSiVIqCnfz/Eh8q3vo/fCdrmnbyisaL3xc1lD5ocVu0QnL8j7D8AJw3290bR844f+cFzvyARZM7f3Vr1iANjxIYnUm1fMWV9zjI1KHyqamJUJpaQ2Ul9WB3e6EkJBgmDV7AhgMZijDY2JVFMTcfw/IxSz0E6QCmJiJrwK77dWT3xS9/+Vnu7YY9No25MPACLCEV7IDwFOFBNwMBOL/H9Ynf7Msx2VOnrfBwkyr67HEPocQJ5s6dRSsXT8fsrPTwOPx0AUiIkMg//e5sPqJeRAaKgenwwW8ywU/J2JJUPDs3y1d9/r2fbX3Llm2Aa8lEuzIB7IgwJjC7jB9fO/7Rx9uHy8ZxYismU+clYZnbrXZPXKiPQHc0NAGh74shY6OHnAQoHjcZnXCieNVdEcMRov3rh4efokEBUnlS1eu3/rSP3aejU1MusurgPfLx+NAZF4lluSN63NahPyOKUxmJEMWthuSP3Q4IAQhBjsxgiFDIsBmc0BnZ493DnbsoCAxJCREgUbTTpUh97C7MT9ipLAmIxKUYgbcv0wPKg6Py1R0tWR5bW/rARAsHRhofMbmEApwnUDvwTJyTM7qpSue2vbWmwfZiopGTCMGpmDarFnzW6jEf7/33iHo7TVjqiigYOVsyMnJgH+9dQBOn74IHMcCIxaDpaEZNIc+AznYwA0s3ITIxyLY5xoT8mTj0OAdfACzA4MOJ7CL70d9qyd+zZRZy7YRq5vNNjrH6XSDAzuqSMRheljB7TOp3e4AiRiP9VroHJ7vMzViWWCDg4F1YvCIgZsUNqvGtZ1BDrYhUfLuT01AS2aM7+MWZREDPKta0KIdVhgermSJ1XU6A0RFKcGEFbFZHRCJHZUo5XZ7IDxcAS0tnXhMiXeIpdFHqZRRiuksThjT2wGL60p8O3DTCgj5wH3m7oglbSppUX8acYFuS4ak8sj0J57fsmfXrmPs+fIG7Kw8DB+ugvVPL4KrLV2w8/2vobVVCxKJCOYvyIY5czJhz55jUFpSg3fCRf1j3fqFYDZZYccH34JI6oHYCYtAiVdy8XCrwi7i3Xs+sVyY1O2x1gTmJa7Pa8lPRjRrwWN7ExJVcpUq3M+3SGz9WPw3hy0sk0lBpzVSf1DFhkNCYhQkJ6vgTPFlL3EVUoiKCYXhKXEgQd9AUHoK3LV5BSjD5MB7bl0Dcuuopoa9r2x89G7e7XYK1PdHIfJitMdvCMahMkgqwiANoNebKFASYWJiwmjovHpVSylHtA+PVNBYr+82Qnu7HqRSMY1IMaowEGOfqKttham5o+HV11aBQiaBgZB9u97ZeGT/7q2CcTnBc8USeVzKiLyXKytbwGKxQXS0EubMzYSICAUUF9dAff01GlmSklSQPTmNKkfifds1HeU8iU6jRw+Dkyeqobb2KlWQ+AjL4QAoFsFAyfz8R14qOXlkt17X1Uawc0JmK1i99o9dhkh5ZWUztSKx/P0P5MDw5Fi4fKnFG12xxkmYLk8/sxiOfF0Gp09d9M+dPz8LcqeNgSuN16GurpVGKg+J57pe0J86Cx68Ax6eHwgd5HmZM/9UePSTtcR9OW9JIY5sagt65NzZKmx9O128q8sA+z//AUIxd6/g5ESiEwmRly41wY7tX8GFCxqw4mKNZRF0Ywp9+20lHVNj2hCcLhcOpyIRmKpr4fKaoxDicYHrRzXKrYmMgVVBqejPdg60aDEOo1Z3wjM6Y+IbEsz1pOQYSB0RDyWlauoHJAoplcEwKSsNAzXApYvNNEQSq48YMQQ7ayyUnavDlDLTcWWoDLImjYSeHhNU1V2HpGtNcF99Ocg8NrwjzIBRqTJD8Wz9cNmbNEO7UOwyJ7YYAbV48RR49rklkJExDFvRRa/4+ChY99QCWIGzrQJHGaHuycnNgA0bl8LUnNF4d/BctxvCsFOvWDUbnsJhNzo6FI+RfeZwZSkiQW7ArqHXXA9TJ+a44GiLWToB51PqvNWYBgaDBa63aTF4D+W9Xm+ELw6WgBEXZ0acgYkQxS7i3ThQ+AM0N3dQ6xN/IKXF4cPnaFndpe2FBOIjeGcZliQkNGA7EGmHTKmdj0Pzps99EEkn7SWW7cVZ1G5zgg2XBrJgCQ6fEpDinwYMyoSBszgKcTiqhEeE0JiuxQCJX5AwS4q8uLgIWpmacBIj84xmO2RnxMMLBdNAgUMsP3D4qewp2rmMszpkWdNyU2Fpfi4cPVoOn356Gix4YWLBRx6dSyvMt/95ECpxnCdhdPLkdHhs9b3UYYkzk10jWXlp/jSYOjUDtr3zBZw5c5nuhsvhBHFUOITPyIJgGHhJ7aydyNidQWndmCLE0iQCkVqHWI8UZr6DKPTgHSAWJjw3ma10bg/OA8T6BCihHIlc5P1WTCXi+GQ+rdmxb7nx+GCIasjQkWjmtLX1iJWnkHKht8dMwchkQZQyqtgw6tik7icA7bQSZbFzhtF5xPpinKQI7wl9SPIyGM20+nJg65PxvJlj4a+bVkAIpuhAS+f11gb0+paPDUVF5xSEt8QP8maMxTS5Cxdox6FOfZUmHwJu5ao50HpNi522mDo1oc206WNgOr4KP/8eO3QTLeZIBl9eMJs6fGFRKSTYDPBYvAhCWPL0YmCdwMG7jdzItGEK0eEKym8i48enwIQJKXDqZDWoa1poFCKl9LjxybjGCYXDh85RehAhVWp2djoFX1nZSMeJEUZlJEKwVAJfflcFprpaaD9VCSaP/ZbL6Z8RBSuRpP9FpzN6DyGYAiQhkSSm0XTQ+h9hjpNdqFW3QgUG2d7e7eM4DpmYRufPN0B9XRt008KPpcffK5rrUFWlgbqmTgg3GyHD0AkS/A8ex1KS0Qfq4lnGgcamrzSwrEQhnCqJoxKAHOY64T8ZJicvp8tbCJAqUzh2knKBJC+cTECEHZ8ewj08vQc1iFRKwec3XwAFP/A74BAzOm5mZnyHmJMrBiNKEJUTeBUkQjIE+Z7oDKT0eKx6btm6uQ3j7/5NCgyWoL6nHQMt1eVn6pnW1mY1kOedg3UNEngi7deaa5m6mupSuEOluVFdzlWdLT6uP3Me11mDaKpBEPJ09GJZ8THOYDJ0HFm44nyUmc+8kxToDmHOGyYFt9GnEupQfneEznFHKaBJln4M3keLCOpiuN2TGi2vcR5eeieAd7PIqokXf0gP9ST7WEWg1YyO3TnWJHnyTlBAHebcaRc5tORYyAmPrsuHiTc/8OxrBRKxRH47g7c77KbPt7+8GZkcwqNFX1Yz9LR9rS7ZVPD4M1tvZwU+++DtV3pNvW1CUr+hOCkq3POmpkFdcdvG/Su1FUeK9r4R2AnznZu8I26ny/n3TRvzLQaDgZykbqfLajQat73+4oNut8vp79OQAnph3th+LSWAkUERC/LDRhfiWpS9HSyP/dR9wFKz5IpTXyQ0kpBPAe5Hk0ntb9cV7Ss7vH5KrWnb7aBA2Wjl+sahwUXUxHxAR5KGUX9n1tunQb5avyZe+i5iRO6cK65tWNP/y06QxkZpmuTJ+gTxDn/bDgW0gWki+6k+K/J2AC/FiXaYOU/n9BrzLrGLD/k1wbtYZCoeF1LQGiveL7TAhDYAL/A/MIyC70jZX5qixQcOJUZOfDg19z9xsvDxvwb4dqu+qlBT/FCXrfeyFyjysoPxml1oCtNPDCwiDQ6hzYR+3MqkXRD8JeLE4gUPLH/+/mV/eFEskQxKyeFw2K0HP/n35kP7PvobjjYOAYe/kYq8vELk8xTIO8COTIqBvt0J+ICC/83eMY/H7VZXV5w+cfSLD0jpPTR5xBiOE4kHJLvabZbjR/bveHvLC/mVZ78/5MGLIYRuNKT/YIf8D9zIdUMYFUJp3xsQbTDTAzptK/XdMCQ0LDJ31rzlOTPnPZyUkjbhZs8T+J58U4P6/A8njuw5/d1XH5l6e7TEsgHdYG+mZfo34AN+RwF54Kc+XuO3gs9H0A0WQX7GKaTymNQhyXlDoxOyVGHR6REhYUnyIFmURCSmdZXd6TCZbOaubqNe067vrGnpulpa36Y5brSaOgLXQALB/R4rfBTHt16gq/rG/yvAAFOxLR3ycv7YAAAAAElFTkSuQmCC',
      },
      {
        code: 'AU',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NjdDOTY3MTA0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NjdDOTY3MTE0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDowNTNFMjY3RjQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDowNTNFMjY4MDQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PpK5asYAAAtESURBVHja1FoJcBRVGv66ZzKTyZ3JZW5C7sOEHBAIBkg2QUUQSuWIBGOWLVwoAV1wq4Kyqyt4i1EEXCgXRIKoy6ogKIIcCgFyYyB3yEXuO5M7M9P7unt6DhhijBrwr+rpnvdev/6v9//fO6iNK2aDogAwDPmhyDPF/wf3l5QDNE1zDxTfkKunNPXsvW/A1LG6yS6uvsV2enuXRUBnj5lX/6DUYUQpMmebmYhVfeay4VZbq/4qB5veEg+nrkuT3TrOWMiGWrhutB/knykjZcJ3oSvmHsVcc0bNNWK4Zoz2ZUrgkOuEJhej7WFYJbXLL3F94mqF6+ONbTaRhl0L7wBLlvjhjS3TpB5H9svxrzf9cUPxAKJX4i3r1Uz6/uzcKb4NByMC6vebmY60UwYM60hN+KOFMgZaBXMCcFxTGg1rvsroNWIF4tpoGLJUwvm+x1dvXJ/W91RuXqc5bkNRUU5IT5+Nme05wLwYoLwcSEgA3n4bCA1F30uXqPoW6yj2+u6y35aowBv/mRNZ+aq1+VCDWs8S7A+t8QRG5xTaO63hTcO+YD7colBarRbHFtY+92ytqmzm3Mf+plKLjTLv4mKOffvmIuvDEMx8MQVYuJD1QeDoUeDkSY75wUElCgvbtO8QVzO7WOj59NsZs0vP5Xk9p1LBRFvJCArk7wyjUygEAfTq+faMnvYJ2fUM+K75Ojfr/qyKNyRqWBhjXCYT4/nnp6E88yGkXNoOKiIcyMsD3nsPuHoVmD+fa3foUCn8/T/C4cMVt/QxPCKy+OZiwBs7Po/Jam43D2I0jLB3RlCzxjUEPmloq6C7MzrJg+zdF649mpPj0q4IN8Y429/SpX4o+WkZtsgvwSwsCPjwQ2DdOqCyEli7ljiqGNnZzZg581MkJX2D2loFRqOGNqsp738+43JRldMi3hPoWwa28G1acBZKawKNNcilkkauSg6KOywdUVoZ+1BEhCPOnVuMQ48r4cH6+YYNQHw8UFQEbNsG2NigoaEPKSknEB39CTIzGzFWYq3x8fEp/7181W0VoxuhutGrIbGgcIrhI44gpFdIwupBk3k7aeqK0Q+8+OJ0POzVD2rDk8CpU0A4MdDZs8Ds2Vw96+dvvpmL11/PQV/fCMZDaoYSHT4T/G/2HhNat0sbXDSjmBEEEAqEuuDwmIdXrEvbzsX/fcYFWDi5H8jPB1atAnbtAry9tdJXVXUjN7cFHh6W2LEjzuj7X35ZyV1joa/OBW63thiqD57ccsRACC4P6AVVtszRyS0wKWltBt3TI+LK+/sNe1Mqga4uwN2dvwTq7tY+etmSK8FhVKZuVLQRAcZuiYMnQjPWL704zVHeV2wwDjYkz9bEXAYiNWOy7nhetnNnbxh+Zzo3ZyXmnA35Re842yuurF+WOZXEhBE+oVH8IBZMcF9x/TMTwfx4qbHNMuzHfK9nBfdhw6tWAKuBIZfEn6r/gbucTmV5b+7ulbpoExmlCfzxhTWbJEqVxd0uwBAJr99nT35eG0bVhHkLWmI/denKP/OY6CYqKCBh4Cvdf09P4MknfzUj1TWObLQf17vZRa6p90+v/CdBuG1cFIpIXJhssvxpGVdLgAgGBvi7OYE7Bw4YCjBpEpsE9FQyxF9sfJNIoJZIMTikwsiIelQmSl7LYVkZlwAEO8nySpyTY8Nr0jmVR8YkJpPgDSxbxqV9hJDo8O23KCjsuG0nCoVGe1IpL8CmTQSqWoK2tYHZu28hL7MOs2Z9TpLxLqPXa69l/yoL5pW6LOfGgLmFlaPrjj0RCAgAvv4a2LIF+Qd/QOz7FD7aX3zbDhYsOILt2wtIWiCadiAxf8cO4ApJejNmcMLErU5AQZoYe3b/CU5OZuNm1N5eZjyPNFtF9vRJXWjfstp4ats2iqAstJwvQGrFVETFfoHz5xtG7bi7e4jgtbPEWB8Tuav4wuBg4MQJ4PhxFp6CIn3+Ze9TqDoUjLS0qRxi/aWM79zJZ3I7O1ODejYNlNfJ42gPqWX08PmLeMVvDbxjTxAsXwS1mhnzh0pLO4k1vkJi4v90GP/BB0H+AO++yzaALO4+vFKzE+XfxxMv9QdF/Xy/s2a5oqwsBYsWeZMuniBI1sWIFayj6NJ5zwb4L79GsHwmentHxh+fT9USPJdBoNEptLT082OJhdQVBPevXw989hlc4yPxifcFXDo1n8xr7Eftr7KyG25ufFR3d7dEdXXPLW1aO8386b9vKvYxVjkeUqkY7NlzFT4++7hByiJS2BJglJ7OT2oSE4GtWzFteSw2TOm6bT9SqQiLF/uisbGPnx8QSM7+Z8v1qa3b3JfuH5Q6/dbJho1QaWkXEBi4H59+WsYX+vsDR44A333HOjg8awtun6xIGH7hhUxcuNDIKeSHH+qxefNFrtzgO/0SJ+KN79zW4YOC5JgfoIZfy1Xd4JXJUegaRXi5jo6OwTEJNG3aPVxfuvm1Cs05pThWNPp73t7WnCsFBMhRUmI8pI8qwN1OIpF6mJaYKBV/VAGkJioFbWY61PxHFUAmHemkbSx7K/6oAjjY9JXTcitFyVgah4U5/KJMOiEC2PaV0s72XZfH0njlymA88IDnXSWAq6Mil3Z3ajkDg8U6ntgsKCQOsZjGo4/6ELjkr62Xy025604Ruwbh49Z+WiyTDjU7ybvymju4FWYDMJWTk8TF++vXuwnglBGIMwkpKYEEn/gQKGBHgNyBO6j9njwr86EGzqkDJtUduFmAgoJWkgkbyOQryCDF79mTwD1v3Pgjmfco75gAU/waDrKOw01ogibXHRCLVAM3N3r55SyjL9fX93Ip/k6RiVg1EBHQsJ/L6uyPqWSoLdi7dq9+I4lEhNTUIKMd2NnJsGSJ7x0TICqwfq+Z6XAbOxK0s/jokJKtJmJlL+dfrhY4ffoRrF4darQDU1PelT74IJ57nkiSmKh646Iqt7JzcHZdSDQ9xINb4ZISSCGiGWVNk2Oio6MMTU39KC/v4mK/s7PhXsaxY1U4dKiMm7U1NvZP6FiYG12+OcCz7VthSVSsv2EQEVCZXlLtllRZiXAWBXKznhuh3DK6Pm3alIni4o4Jdx0Xh578mWHX39FfRqd1OxrsTpB65KHY7KUE4GlnOLa2Uu6emnoSe/fy+NfGRnoHgJtSkTS3YJlIhBE16z5qtWZpUW8/jLWCrWVv+YMxOSsoiuFmD1ZWEqxdexYZGSVYs+Y05zqCUBNFNOFlSeKVZHubvjK9ST0PqWfcawgPWMvIrXpLCUptraq/56HqagVOnqzVCnj0aBU3M+rqGpowARbMuvZ0uF9jhsCfVuXkj5g1g3ZfWG+1IMy3ahdrhe+zpuwkNdpQw64D/VZz6LFo/uFZ19ZMDardbbjBqnuiuQ1uTUgSNtQEacJ8a3YviL38mP6YmLhwqexdNjdvcVRgzW7e+jrmtRbQX143FETX1Nej+cvkeWejHOXd+RPF/D12PVf++siF6CCvpi8MdyZvnf1yY8DY9qUgFEtmpiMdISRTm4jVgw2t8hg1Q5v8XhBhTmT5S4vifkq1kg028Wc0jCBRzS4+K442kekbiDvMoc0PGosQf3R1bP/xXu+6fWxla6d1qFpNS34jxvujAmt3L07IW+rn2XKMxHYVfZMSBe3r9vQ04/aZpFm3LvVRemcVDIu5F9n74JDE/tp19xVFVW7Lm9ptImDksMfPEONs3513r099RpjvjY/ZtX6KP2rCHSqhoDu1Quntreorl9IXgNEMCsPjNkaE0K/XKKJvQOpU12wf19gqj27rtgjsVvDHbYaVIgsBvxDw1Wpj2V9lb6ModnPsujzJue2MuYxfUKC0Vhe0x+jtz+uO+wg60hfi/wIMAAVxZpn2WUmyAAAAAElFTkSuQmCC',
      },
      {
        code: 'CN',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NjdDOTY3MTQ0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NjdDOTY3MTU0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo2N0M5NjcxMjQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo2N0M5NjcxMzQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PpIfBJwAAAp4SURBVHjazFp5kBTVGf/e0d0zPbOzwzLsycIi4LIaARdwLaJQmzKCMcQjIgQQNYfGVJnLpCqJpZVovPgjSeXQFCaiQLBMTEUpqSSVCv6RlAcIcqRk1wWXY+97dmZ6+njdnfdez7hQ4ZjZ6Mg3sD3T/V7373vv9x3vfY3qqirA931A/CNFHPzga+4QXEH8Lw5aoVxT3/Nk3wSmlZ/GtHUxwlfXW9a8hJGdFbWsaZrrRnx+lyygzAiCwX5V6RyKRdo6Y/pbB8PK60dT2YGU6fH7YvA8Hwgh8ug4DBhz5G/f93LP8fh5W34nvD3l1yjFgOprpwHjF8BH4h/gvCr8D8cmlciDRgjnfgCUezD1RsPcuMK01jU5bBGC/AgUJuLW7Srd95qq7NilR7aOUzIs789BMMbA4pgIJvK5eSVcl4HrOBIhIlwJyo+Ncxoga2aB2bZsCDklhHg5BTDGH6JL+H7NHZns9241rHvDvh+Bj0BMhIxXwqHnXoiVPTFISA9jLmQtC1RKOUgxKwK8K0fU40fXc7liiONCQGqqp3FmEAnU5xfyYy6oIRTIjzxXlnLgDzw1ln55kc2WKwAqfERCAZRPOeyqWzPGvQyAHSZkr81cjxAqaSSACjziI4BLrOK3wNfUOBuoonAaOWAaWc4zU2rrn2YADR7MfTKZfqmRuVdCCaSN0gPf1dT13XrkPUWlEovH6cP4f4HelbMQ0IpEIyGgnGuKokrDELiD6QrmotV2bvp1MvPXGs9rgBJJwvOqb2Hszk6FHDmlaW35UUfS2QSCOSsI/0F0jUqOCS0J5xtVqOS8x0/camTv+Wkqu1UDCEOJRVD0etNaPYxJX5uq7hNUFpiEfQgvhQT/uSGTSFiV0+F5TBKeSMNR4JZ05r4fjKZ+K236ExLx7GtNc9UoIQNHFPUdMcoqN8ZIiA8yxypslJSX6YGVcwWEhXPbhmWW9YUf9g688EmCP12WmubKDk09cJzQ9nKdwiW1cQgrBFKGDWj2zEowLVcaic9Vmg24adtock/Y86NwEYmBUPquysqr+nRypD4RgWhIha6BJOC6Cgp6KKCNgrDyeDL14sUGXoju+9HHRkZejIXDSirrSvBRXQN8SVUEGio1mBJVYKPjfPtS5i4oKbIQKbjpXMdZ8MXR5HfCephTnqccnPK4ukKHedPLYEGc1n4lZTxcEuO8rEwCR1MUoA/MLqrv2v6Rh6p8vzYc0qQSmHBrjoYprBnO/Khk1OEP1vYsA/XVFkA6Kapr2POiq072PUh4IiciNBZuVLfcxIITY1+erK9D04rLKvyODPh9FqBLo0A2zgDlV/MB1YYK7r98cPTuuOcnRFDDFfEozO9KbaCuN6lghReWA7mttrjc5/tzAIZ48jhsA/vlMXAefA/8HrPg/qrnh5cOJjcwxilUFolA4/HRDZNlA76hCvDKqqL6sE1HwV73DrAnOsDblwQYZ0U/95qR8fUmz9+wariV5X3jzZNVgNxQCXhJHFBCLcoGhLg7usA/lDyTkXWFUWmuaS+KZbK1ON459BkocjHy4cNmRwDNjcqVGr6+clLG7HMqnZED/ewKQDN1IOumA74idl7TW2g5rbi8a6Rl0qO/YgI0WVn5/3snERPiFLS3lgH50nTw/jN+3ubzbLaY6kOpeRfyMmTt9DOn1uYrN76WJWvrJmxheQLoPTzj5skWnO4aedRkz58EyLjnfwyfSeWpywBfHguGN0YBxRXwR51z9qlnXiM6VhHp0Ecyc85783IecDZdBuSmmuIYcngcnK8fBP9YpnAPxQcBtybA3dkH4PAk8+Wec7btVulRdEqj49RiZQVR5vY6UB5vAojSC67Y2TOd0ssIEEV5NU5F/7gBflv6wmtpSlKod2L3pDDD5Qam/GY+4MXxs2PvNcG5/zB4/x6e5AKZ84cVDqloBWSnag20A61nveZ89QC4r/WVJCNhCNmYqTRVdPBacW6Pg2+sglKJgVEK21Gtv2j3uap6gjLvp8HbPXimaw2RyaPiK3Wypq6gpuMIjeJsRfRoUfThERcvrQgi6R+7wVr5Jtjr9wF7pD3gLneh5LrEpPHjZp5b3Vmfi2rBdua55CQhHTgztaytqAeI0bc8cL51GJxvHubzGGzBsKc7wV71FvinskGbYu1qli7Ta/VPS7gScQh1rwB636zz9jlBSTtOTp/ydlEKNEbB+uwb4L7U/b9+/90k2Ne9wS3ZL5pGfqcB9uq94OcSO/bsCZ6pfvBh3nQ2OULJPjzcMO11KMITOQ8dAf/ouQOTn3S4Gz3E+eUVPwt8TSDWCvZd+wFfGr3g5vBeVdlN7YjWP14T3x/rHVtUmAYF6OoX2C7YYpsYZdMF+/a9XHm+3n1zlNsAPmcgbFPo/kGMe+S+T+/8+u0lXcjHcpGcR3T6tZkTevNVmgCfn8nzRfG/aeoOsdElFei5YsZ2l5JsqfCTZQlQX1oC6pYrAaq0ovtbCGV3hdStYqqx0NfW1aHuhTO2lEoBGanLKeBrp8q0WXm0qeCFjJCdIXXLGIYhkbZiP7eP/sGyeY+5Kk2XZAY+Xy1zKuGCvb8PAHvuBPjdha2JxQ7d73T1sRzRAgoJJayyUM+x5Y2PlGRXpSMN1uW7wflxG3hvjkgXWqhs1rVH+xHqETvVop6G84sWoc3xljm/GK+Ov/txK+C3p6XncbedAm/PaMH92il5d3tY/bmsGuWqkTio1+QcK8bOwduWrGF8jVASY/Ch4NE3ME49Wlu1FimqAxJ2UArDeW+dLykZFdGOw7csvsNHyL1YNna5M3WfrKve0B+Jvq/rEVBVNae/8EJniTeDjTU72z+34P6LRYFNscj9/yR4p6iiqpoKIZ3nTaGwDII0mEckSzanz23X4lnP8AZu464DTyPPJ5/UyD8eDX3jzyrZTExD4lI1TRYlwygwX1m5niig5ZwTV0jw52Rzw+aDq1tuY5oyXmrwJkbph6viq18t0zeL0pfHcysza0DWMMBzXKCEQiRSli8hBTVhgV8ogfIGxj+DTTWv7L2ndXGq5uP3TnkZKA8dfPaamS2d9ZG/iJ1zRQlSD8/juZJlQsZIgWVbsqpKblqW2xbiWubfgch/QbJixlNbXRvpa27YwtMNM941spRTSvlYIjTF2X0Lan7yj6tn3O1EtT5dI0A5AJMnhswF6fdlzThXI0YYA7k5pwBCZ77tIKqAKFcZl9cwdpMzE//qXTjzeXEq2j8+H7veR1Kt9xRiDLXM2vz+2uY1x+vKdpmO54pSr8rRh1TC6e2CYXs8zxOIPMkOL/fuBPr9gzdzgP7E9igKJoDkv+fOIzShnfiuGFai5uDJO6oOnVxf1jvWDH6R+6scS6auYv/wlTP+MNzcsM2NKkPYZ3xV6sLgSBp6BlKQtWxZhclaDPrHstDRk4GkwbMG283Vtr1AgQlgwcsReYeEcrSS+sEExRDKsyw4oabNqinHB1tjXSMt+mCqKTxqzFIy1jRiM7kqETmWE9EGrYpIZ7YydiQ9o+Lt1Jyq11k01J/TJaCwGAVOGZdZMDaWgVP9STA5eJvzx3QYDIyZcGLAgKGUJ5USb7X8V4ABAEODmD1T6fmFAAAAAElFTkSuQmCC',
      },
      {
        code: 'UA',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NjdDOTY3MTg0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NjdDOTY3MTk0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo2N0M5NjcxNjQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo2N0M5NjcxNzQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pt1z/N4AAAXsSURBVHja1Jp5bBRVHMffezOzs/fVPbpLW7oEbBsiR8Eit2hUKEHjH0YDRQNECMY/UPxHDR4oUWM8YjCRRKyChXiQIBIOjTQCElBawEjp0sq2pXQPlm33vmZ33NnZ2dnpbokolp1fM53Zmdmd7+f3fu/33rz34OypkwBjEMLMxhzRgDWY30HuFPeZ/Zfd0zQNKEJtCijrlwRltnujpKU+TlTYkrjKmEakgvkKSsfDBBW6Tia9DnnC1a2KOE5rIvZ2IhX0sM/hnwkh92Q6r2u0wex97Hk4FgDkfmYMAApXVni1c5+6rm1aGZZNnAVAiSfd1GhaGR3oMAR+22P2n95FpCI3BA4C6TEB2PMoe5cAgN3TefH5RxVAJAiNxWVa+qJbt2gD5+H/aiidiJj9pz6v9h55W0L5hxhfwAIAppRZfTBXXnQeAJtg1gsBACz2Zfa7CHcZH97cO/HZ7wKKuxbTEJeA22Q0xIiQrLbJpVu4AYIUpYz2/Y5AOi10LOTDGoBcqMHiEuAv8t6PS8xTems2fB2W1cwE42CK2OD5eufOVfK4swveJDIZAMxq0hUDIN7xw5oZj9prNx2OSwy1YJwsiasrPZq5T2cq/CV5wt19ywBMlDEXPfpF6x3V63alkUQGxtmYEPWqGx+XUAGXKj7QUVgPuG3sEsgUgcdw38a+Cas/zX64YwaRTzltBUEFPapY/1kuvLPiafa4qBIzcCOaGY84qtZ+eWfF8zasnLpUEbt6XpH02AWlxGQwPiuzeTLTEDVcqX6mjYYIA2ViNECY3bquLSKpbODPsX+IEw6yTQcirtSs35tCpBKUmTGaLlnX7WVSLt/wQiAIEY/poU0RWfV0UKYWJqumD+oeeF7QCOZTF6G1XjOveBWUuQ1UNG9J4BprEYDTvPzldBmGTqlQGqhY9ooAINMxM3j1C9YCkZhLM29NElMa8gA3dHNb7kRj9W8tDQmZR93UIgAAIjO3umkVs8cpXG2KyGsaxQYQktbMYiozHlDV33/rLyPlYBCOyOuWoLB80hwgUgtKJ85GUbKyXqwAUYm5DsVJ82TRAhCmKYgi1GaxAiRwlRmlkFQlVgBGO6S7AC1WgCQFEygSRUHR1oEYCqIbfswt2jQaxobRVSfRK1aAQTfRg/quEd1iBRgYktjRnz3kGbECdDukHejsRWk7TYsvEzGaO7oUx5BvBHN3XyE7xQZwuU/a6R3Gh7LvA4eOK74SG8BPp9R7mC50dliFAYgnYFQs4hmtR05qduXfyPxB3HugXdUqFoBDx7Wt/iDmFYxK7Nyn2xaJoZAIWt/QF9/rt6UzeYfZEDsDAoDXhw199q1ua7kDtO6veJOpvIJhFW5gd89B9Ud2B3mufDMPee6bw7oPCwfYc2Oj7EalQPKlD4xPhKMoUG7iM+EdfG279UkqBZMFrQEbQoLm2Un0bPnYuDqdBqlyEc9o2fqJpeWqU3I590KfH4fALAZt0VRm/xBhHw5g1xfMii4vB4D3W03P/XhK0wa4yY2Ca5jFqC05F9v1F3k2U1mc8xsjzaNHscfT8+/tNG/c/7N2R+EEDH8ASwNwHaNMF6Ojp5/8Y35jtFlC0OR4p8vXt1tWHv1V3QYEmmFWIFsYowC4yY48EJ0Np+5jpxX7ZjTEFxh0Kct4iO/tJy+88G7VsgvdshPFvTgg0JgB0OXO5hJTXjwP4w9hvh/ala2JJIpNq4vNwzFA/F9dhM/3Vbzx1o7KNT4/7so7vtR6CW4CvLHBBkYvtmBBabaoBLOXEBj11ISWFf7Njz0YWC8j6duy1CAWh5GDv6hbdx/Qv+Px4YOQV1MSgJ9yzQLUliQrvJEuqDvcda0qZWheHFq9bGFoVZ0t3ghHL7D4B/15ex/ZefSkqu3ICdXukUx/rPAXIF0sHObin10rkQOYWW/LLvAYu7g4L4wtRq9Jme+5O7Zk6uTYHFtVosFqomw6dcook9JKtkLCEJOWhzyEI/MKe+lir/RM50V5uy+AufmFJLBg5Q2d939JiAL7W4ABANxGNX1ltuqAAAAAAElFTkSuQmCC',
      },
      {
        code: 'DE',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QzY2RTI0RjU0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QzY2RTI0RjY0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo2N0M5NjcxQTQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpDNjZFMjRGNDQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PqB3WDcAAAZNSURBVHja1FpbbBRVGJ5zZmYv3V63l23XFlraAqWGKlhQYjBg0IgBfTEYbgmaSDA+aMQXiRglYGKMEHkRNaBAKQ8QfVAjFSxQtTS2pVSwF3qju912t93ufWYvszueM7MzO7ssGrQpO/9mZudy9sz3/bc55/wLNq5dTiQEEFDYow0A4QrP88IVfAogj87RMcET8dvCvVCEK5lx+dfNegOP+wPBpUwwXIWuFXPRmAG3oEgY0NLUtEGvHc0x6PoL8wzXSgpyWrUaygEgSDxd6BQ/QzrnZRypImJEWzKB+A3ho+xUErFDfCkciRRa7O6dlinXVrePWRn/6f0IX5Cb1bWwzHim0lx4UkNTTiIOChMQHys+DysxlYiML5UAFqggQCRZAwHnImVDFsfeMZtzdzSu4f8rJAmZKnPh8bpFZR/ptbRNInIvAsIxL94naxea0phHIgDkH6BOqGHr9Nudt8bOOd2Bp9C5hpgjQX3Rs15m1Yh1ejeEkCvMN/yBnhkTXQnc243QdXLxAlPC7+OYlQRwowAbqm3vHW6x2l07Y3MIPFVw33and4PN4dlUnJ/TptXQ0xJ20bUSlpC+YYomUnVDTM54XrjSNdjp8bOPEvMkKKYeudjR1zHhcL8o+gqfzmyCksnFShfCriJZCx2MTzlf6xmwnIzFYnpingVbw2p3v6TT0lNGFOxi8gDJQYx2ZG2lKeE/igZ3Jp17/hya+DzVSvMs0Dbt2aTTUg5EojPJfYS4RA2SvUY8QX64+daw7SiRIdLdZz064fBsTnZx0bXu0q6fCdX19I83ocZkphDAWK71jjZ5A8E6TAK5NCFlKCjldymd9fTdaUb5PZvIMEFv9ez2G6PNKDZoZRqFiqAmRidm3kQsG4gMFbePbRgcc7ylDGiZQCgcMQ/dse8nMlxuDU++x4YiZjnKxcDgiWGL410uA10nnSshEvswbrwJFghHuCLrlOsVQiUyOuHcFQpzRcJIF+/MDvf2vQ/gZfWfJRrTz9qc232VpiMCgX2IQA2hLhmxzW7bjwkUcNGSxX52BVAZgRovs7IABTNscPvXg/ufjDxwwZjrnb51cImXWU2oVKo8gcdgORtaqlYC5kBwCTSzoRq1EihlQrWAIaFXH43lqJEAS5E+wKed7qhHoJrBcxCEIUtCn1oJsCTpgy6asquVQIAmXdCm1wyplcBUlu42tOi0/WolYDNoB2B/blaHWgmM5Bq6YG+eoVWNqRRjvmnM+YXCQXy7WN9dy7IrVaV9Q1a3S0vbKDwtu/Rs/unqenUR+HXIeIYfj8/IWh15p199x35IQ6tjVhaOQPbq+8aTeGFCIODxkzMXLuef2LR29nU1EGj9vfCEL0DNYALyUKL5p+KDbAj6Mx18EGE8f8l0UAhknpBW5njC6aFsTT8Wf5jpBM5dLD3g8opVHHltVFrl+u5y0ZFhi/565i6n6K9/31ZyWMihPJ+wgDy6i4LIoeMVW5gg9GbcwC0EfYdPV70c5UBEnhWnG05bHfTtj78p3xGLgWimgMdYPjtTud3m0AwmLz8AgqyuKEmcxl3JatcOeAPU9KqHfc9nAoGvvq1442q3sUmELK6hAADFIp+SgEQCb4Pj+s5ZLz3ZuMy/UbmKPd+aP3auYk9Le9ExqejIE/GBT7xefRcBpSWGLFldozZdb2O9byNN8dr5TpefNlVubbtubJJrY1IFNV5iEggsKi8h0pVhZXdy6Pp/68k7X1/NPGnM5crmA/yYTX/jwJc1z/01YmgTPEL0GSJRt5Z2PLZAsYT4nstzPoaabblWcCLCweCyKmYNSSaqJHM9RDh7ofSDo80Ldrn81BTgZbRE/F8U6FBMn3KVEhMAEngeKDOUXOYXX3YgenPY0PZzR8HXuHnVQ8HlFDk3Re9QGDIt7YVffHKqcktXX+4PMT6eAYGieMrz8Q2PH4CscPDMmnrFIBsIDJVuJFXHpeiXJDebK3q60b1jfaN7W3U5u+IfDJh+PI8UOWLN6r7cld90pavglC9AzyiVd1diEaNaxCSBx58NTyz7VxdKBE7ylELyzfwcztRQ61+3tJJZXVEaqjMZw1V52VyxTitWfHBA4rRsd2pGLXZd38BYVsfNoZxWt4+yY4UlStRAmqzIR4m0CXD1W/zLAZBREX8LMADEycYZY6+D3wAAAABJRU5ErkJggg==',
      },
      {
        code: 'JP',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QzY2RTI0Rjk0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QzY2RTI0RkE0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpDNjZFMjRGNzQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpDNjZFMjRGODQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PhCeNEAAAAm3SURBVHjazFp7UFTnFT/37i67C64Ly/sloPISBeShAdEU4yP1mUw0Wt86bRxbzWjb/NMkTmOacWrTxqmdVpPGqhEztqTTVm18Rc1gUIMIajW8lIcsIAvrwu6ywD5uv3Pv3t3Lism9gIbDXPa+vt855/vOd875znepLcvygKIooADYw4W/eE3hFd7DP4Y9d7nfockzPIB7BcaMDQqbOGlqYXxi2nNhUeNSgkMjEwI02lA/lToAn/f39Vqt3SaD0dBa397aVNV07+7Ve1UVF8m9dsTg+YObD+3mDW5+wMvHyoWvMd7nQgV4CFZoijunaRq4Ngx3TS7wDhEwOHfW/HVZ+XNXxSQkZVOUgKsIIniMvqGmvPLqF8cqrpw7YrV0dSIDimJ8FPB2FN9nQk6sAuDWTki85qiAt3MYCAoKiSxctPKX+XOWbvZTqgJgBMje39dTVvL5wUsni3abuzpaBijgKxerBMPdJzLJclJjfEwGBm0sk8nlLyxa+YuNO94tnjgp83ly6QcjRARbETs+Zdr0wsWbXU6no7m+uoxhXC4QWIZv71Lu4ZDlpsUOqqlQmbDI2MSfvfmHs2gycrlixAR/TBGCnZiWMzc1M29xfe2tkh6LyeCrAjXwH1EgNRYYYJ44ZBm5s5b+9Ffvf64LjYiHZ0QarS4ia8b89e0tjd8YyKQXzgNeRt7pyHImxfJTxTs0biqYs/S1dVvfPqLwU6rhGROOxuScHyy3dHe2tTTWlMOAeQG+Cgg0c783c97LW370kzf2k3s0fE+EvFMy8hdbzKZ2fUP19QFejHVZ6BEF1o7uFd1lek7Bklc3/XwfjBJatGrbvpSMvCUoGyV0r+QQ+kj2NyI6PnXD678uIu5TNloUQFlefe3NotDIuFRGEK+ww2lfd7Zp+65PlSr1mKEyY/rt4OzqAkdHBzgePuQOco738NlQiUzDMSs2v/Upyii8L/eaEAOzF63YHhM/MWMoDFzd3dBX3wC2sjLovXMHHG3t4OqzcT1IfIA8IgxUaWmgzs0FZUI80GPHSuYRGTshI3/uKztKTh/fI1CAE16rC4lauHzTTuk93g+9t25DV/FnYPnqMtj1LeAyGsFl6wVhfkKrVUDrdKCIjoIxMwpAu+wVUKVPAcpPWlgpXLz27cqr54+aTZ0twHmhGPbBy6u37J6Qkl4gqde7usF0/DgY9vwOzKfPgP3BA1YhmghF+6uBVqm4gwhPkZTEZbEQBfWswrbKSjRuUI6fAJRKKcm9KhR+6prb1/7LXmcTN6rRaEM2vL7ziK99fRs5SS937t8PHX/cB/21tUDJaCK0P1By+cBsS+C88RmtJMI6HWBvbgZbRSUw5FyVNokoKT7UhEcnTC778uQBzKFonMnTZr24RkqwcvX0gPHwYej8ywGwt5OMOCBAkingu9gG2yIGYiGmWEJZM/PmrGHnF/rWabPmrxFvNy4wnzkLxr8eBOcjI8hIz0nMpD1BE9siBmIhJmKLpYzpL6xmFdBog8LGjU/OEtuwv6EBTEeLwN7YCBQO+xCEH2BWBAOxEBOxxVJUXFK2JlAXRadMyZktdjHCOJ1gvXwZeq5cBUqhYCfmsNMFXDARLMREbOQhcgSphOSphXRCUtp00ROX2Ky1pARcVgtxwPKRC7UECzERG3mIpej4pBw6MjouRfTKqZm4wIqbXA/IRi7T4LEQG3mIpdCIccl0aETMRLENHKR37CQ1YACGZ/uDzAXERGyHhBEIDo9OpMcG6sJFrsLZnIZxONgA9BQyNhYbeQirDt9GY8YGhdMqtb9GlPzExTl7e73Jt0gmYjuHH0/kwYh0p0qVv4aW4i1kJC3wJN9PwYTY1EClEu3dnA5HP91r6zGLZSIPCeFSBQkBR0qARGzkIbZz+np7zHS3yfhQtLcLCwNFePhTMyHERh5iifT9I7q9tblOdA4SEw2qqRmeoDZi8ruxEBt5iKWONn0t3apvrBKdypLeCZg5E+gAsmBDbzRSRLAQE7FlEkbA0NZUTdfX3LkmJeAEFBSAf95zwNjtor3Fd3k3xEJMxJYSIPUNteV01e3yi1hoFb02jY+HwDWrQREXB4zNNry5gAVjgoFYiInYUorDdXfLL7CTuOl+9Q0pAUczfx7ofrwJZEE6cBIBmCEogW2wLWIgFmJKCZD6xtob3Y86W9gWVy+dPiopaJKVl279egjeshkUxGYZq5VdSkpZR2MbbIsYiIWYUqjyyvlj7LzMSomG9jZ93eyFy7dJWVLiElCdng6ykGCSvxjAYeggqyor5xKxJ319ObF1V18fWezbSPrsB+rMDAjZtpUVXhYUKEl4spS0/f2j326w2/t6ZFOTY9j6fKAuJCohcVKupABKFuNsqSQzk1WIcdjZfIYhi3eX2QJMH0kLMDWw9RKlyApMpwNlchIEvvQShO7YDpq5c4j38Zdsfl9fOvXRra+/LObKKlxUglP/OPRefuGCdVKLWri+VedkgzIpEbRPuS7ERV+b5fx/PnnPE1z5vSmTsb3lxPGPdy1bv3XPkJJJIpA6Ix1UqanETHpY1wh8sCOuEVddtNqfKKwYlts9/68j7+Lk5Q2U9haqKTh34vjepvs1FcPKy4iAMq2WzWnkmBrgQc7x3nCFJ56nouR08QfeQrRPbdThtNsPvP/WCluPtRtGGWHidvRPu1aijIKCOldW4bUBhoKHLQ9qP977zlqXy+UcLcKjLEV//s0aQ9uDGk5eb9yRZSZHe+rtfHGiTd9Ube4yGdJzZiwcDQr88/AHWytKzxfxPS+UlXWj4L4h9NyN96qum4wdrVOy8xd8X7s02PPFB3+/pfSLfx94YoKZRRSgBNUyGKhEeXNj3a30rPwFcoWf8tnavM1CbH5V+VfnioC3EZ+NPsEIDK4Aatamb6gqv3Lxs8TUzAJtUHDksxC+pbHu5od73vjh/eqbJV4v6VkYemRluDkQAwzA4EpwWwdgNXcbSy+c/JvD3t87IWVKvpSUQ2qKcKb40DvHDuzeaDYZ2wbdu3bvpDLuLwfYSUwxrAPyaDqwIdcDDONy1t69VVJ68dQhLOtFx01IH6lN737iI0svnPjw0N6dK+5WlJ5CXh5pGQYe37EXjMjGJdM9G90UUE+cD55PESiGr8mE5D3/4tpps+atxuLwUD72eFBfc+P65bNFZSVnPrGauzooxr3VS8OgvB+/ZrwKuFMiMhLurUvKqy0lcF9sIx9RtYG68OTJ2YVYZ42MiU8NDotM0GiDQvm8CiekpfuRobO9tb6tueGb+rq712r+d+Oiucv4kP9Og2LcFuv5IoXybGizZReGGTCR+d//CzAA/NsFPwuaMXkAAAAASUVORK5CYII=',
      },
      {
        code: 'RU',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QzY2RTI0RkQ0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QzY2RTI0RkU0MTZEMTFFODkyQjBFRTcxN0IxN0FDNzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpDNjZFMjRGQjQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpDNjZFMjRGQzQxNkQxMUU4OTJCMEVFNzE3QjE3QUM3NCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PuQdJngAAAZ+SURBVHja1Jp7bFNVGMDPOb19d1u39bG1jK3dxl7ACu3YGANhzLqh2QARJgwjJiJiiBL2h9FIIoL+Y+IUA3ExYpBBTDAoCYnRhKdRp7AxQbbJHrBh3bN7dY+2W4/3fW8dMTHC6P2y096ec3fv9zvn+8499/sO/Kj6SQABI5A7IGsgxGRhKshDppH5A0g4kf6tUEeZYhPsa6KMyQWaaGOmShdrk6u0RkQotNQ5oengeNA/3u/3eTunxgZafINdP4/2dVyY8U/0QebibBH0YAoEIpXo+2IstFNCYK4GMBeiP6m6MCCqGfP3oA5Vmuj4Bc7i59JyV201WFKdPO39RUmWOLJkkKWUu4rX03Htzs0rJ+/8dum4f9I3yNbz9+CUgGw1BpyuEPDNH+5bxwNAiJgmzNJDoV/obwSBNkqfmFu0oTo7z/0SoVBpwQOQmaB/or3p4me3fjzz3qTP62H0hqwlCCPBdBFkGVidBQBaP/FAAmZ46SMgQzJicVH5Xmfxlv1yhUoHHoJMB6Z8N384faD1l3M1GIeCHAjk9QszCaaNAoDsiZQ5Mf9AKY5o46fa9AZruruy+kuDxb4EzIEM9d65/tM3H28bHey+JQZgB4C3DsrMEG0x5FEohPkLhDADA8hvW3Z+xaZX3r86V8pTEmtOcbifP1hvTXetp/TArENg1jeYOnZCYWo4pxGcg5LsZe6dpVtf/0qh1ESDORbSv3RFT+87neoo2ckpLbIevhCClQvDRNUtLCh7efX6XUfAIxRyUpHllb34CURI1t74/VGx/lSPQ9JpkbjHQ4AZLnv2svLHynceBhEiTveOw5Y0Z3nYKLAgiJt3uKZYU1KWu3JfHUUdKQDUSCwv31MXFWfJ4v2B9Q2EmccDjUDqLC/dWn3qYU2T/9cnCte/eoqEkQMsPOwQ5p5wpDiKKl4zJNpyQYSK3pScm5H/1F7xWgJhdhbSROstBSWV+0GES07hxrdUWr2Fm3AQYzwYLCve/IZcGXmmcz9Tyirc8Cb3mwYgF2aGnOVlLwAZ6bcSKPYla3co1DpDiLQeggJIzlxVNdA3owZgEkhE1IaUwqp7v39bQwMc/tRSNVTTBKQkZr1h27OrQQ3hm9CYvrusXorBsKQAIFQ5y1waC9HWnVQsAzIIpCbkSqK5w7oGdfck5gOJSqfH6EL9Q3GZUgXw9MdkoMERfZpUAXoHY9IR6cRmqQKMjGvMyB9QREkVYMovj0JAwkLIQgGkVATGpAqgUgbGkE490StVAK3KP4Ti9cNtUgUwx4/cRsZYb4tUARLih1vRPPNf9VIFSLEMXCNs1q4LM0AlCt1KZDFHroYybX+eJ7Tq8d7H7Q0Nw944p5QATKbhBn2Uz0NQ3b4rre7Ekut9kgJoz7ae9AAzE5m7m6Q7seJ8w7vENPVWFvkyQ8gm+9NzjlMxaPqNzK+SDzRnWY9l3OjaLQWAbsf8Y361YoCKCbFRCQBuuOyHpuUyX8T3voLwdazMPETrjdmoBCXjGoWnKS/1QKQDtK3MeMevU3og5mOj3BsaAM2OlBqvMboxUpUfTYhp7Mi3f8BEFjEdnEO89tTwQBC8/ETulqCCGI005acVxFjDBmclhjDIxXNFsVEBYiRGfftKyaLt5IkzEfP+TurSVOGqmojT/UH9ppJJIcwDsKkOKCQ+um3Gs/WrMvdECsBN96I9Pemms3QGCTO54lCINiJmGhVsSsgVtCxMOkqRF1xqPgIxlj2qnr9Runj3XUdyLcTh6wimw0MiJ8azL9CaM6/2Yplj06PwCdLmfVc3up6565hfyye/OTvH7O4B7jnwbxBdNuPX5zYXuOZydhoxRTdd2r4i35OecIbr8rABEO0YkK3NS5290uOSsOQ3lVz2qxTeNvJJPSMnpkw9w4UohOUPa4nQUrTg7cZ1jh1+raqHVgMI2Xco2jcA2Uy9rNhlD9vmwKX2w1BZe+y3xl1pz7J+Tp0SOzi2mARRPBDF5bKJztz5tb9WLN3Sk2o+R92LuzNCIh3YAvm9ISTIwV0lswAA3w7/sZNFyJorJwMGe6tnO1m2xfWNLgX//X0CD5ljGrqyrXVk+SKgkQ8weyJmd6Z4xwpnIVxSeBaAeDaCYQAw3MR4KAzUk0Gz+d7gGkPPSH6M15elHZ20qSYCRiI4reMcklx89Y9HqztH43XN3kR9/UCy4cKURikEFNjtPVBkwmIYersNgnzHcvK3AAMAUqxtJf5NK70AAAAASUVORK5CYII=',
      },
      {
        code: 'FR',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RDM2NjM4RkQ0N0Q4MTFFODg4MDFEOThDNjlBMkUyQzkiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RDM2NjM4RkU0N0Q4MTFFODg4MDFEOThDNjlBMkUyQzkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpEMzY2MzhGQjQ3RDgxMUU4ODgwMUQ5OEM2OUEyRTJDOSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpEMzY2MzhGQzQ3RDgxMUU4ODgwMUQ5OEM2OUEyRTJDOSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pl2Xbl0AAAXuSURBVHja1FppbFRVFL7nzpt96XRmOmNLi63YQrUGCg0tTUgEE5dI2ooaDK1G/EEhgcSNP6KIGlyIiSaYkGKkWln+QCpVDESlmIrSaltZCqVFi9iWbjPT6aydmfeub53ODKUSBTrvZJY3b+597/vOPefce895kD83G/FCCEIgHIpfCEA6mkHYJjarzb50WfmKRcWLy/LmzVuQnZOTZ7FYM7Q6nZ5rEgwE/C6Xa3Sg/2rfn39c7j77e+fp1tM/N7uczpH4S5G4e94sBsjPmTPVmicBKL7LjS6g1Oit1dVrn1tVVbX2/qIHlsBNsY0Dy8qF8+faj3595EBjw+cNnmjESUTg3KVwsjZnJCB2IrwOpvpNi0lpyJw0l7z68KrVtXVvPqFHt0C6KlcHjvz43d5v0tPeG6cUgxx47taiPm+kAJFoPFBCrgNPxHMIMIXsZVugcENPJL3kZQWlviXgOVFjrHvI49u0c9B96XFPYAsmRCncl0wPXgDNH+OpU2SGO1jyoWBdG2St3ImwyoBuk2gIMawZ9+/cPuRuy4rQ991MH0wg2XCmhogfQvP8Shb8b0jrKEZ3SOaGo4u2XXO3Lg5MVgk4yJQlSJYi/sYJugfhT6kx2IrXQ+6Th5FCbUJ3WLjR2DQ6cehBX2j9DQMBRwCIcMgkmBDrRLYlGyHnsTrW1hRoloS1b8XzTm/dSm9wI0qOjJIPgAA3wXmxuaACsh/ZhVJEaly+XcXBcEVSGBIJiHEfJFPS2Aoht3L/bGp+upGoHZ3YnxWJFiaTwLEoifhhUUJu1cHbGWn+j09sGJ04iBmilMyIt5b4iQIySl8ErWMhSlHJCUcXPuoNvpTgxFMzrDELZy7fhlJcKjz+N8w0kyX5bIwAOMpfS0XTuW5OZYhh1bh/a5x/sELpbGBd9AKSiSz3hdYZaMbGzVcCAUtRDcKUVi4EVIRoy/2hGmEm5lZ16UU1SGayzB+qFkyI0ttBl7lYbgTunowu4ZwZI1Puyn/fNqSecLNWYSiygl2JzylFMpW8cLQEI411gVwJ3BWJzsegttwrWwJROp9zYodcCZhoxoGRQmWUKwENQ4wYyViiAGGM6LBXrgRCAF5Mor5huRLwY3BjMum+LFcCw0pFLyYhZ7dcCQwpFZcw8Q+0ypXAFRXVjonvSjOaMS2XmsKltro0qhOYRPzDJHCtQ24E/lJRHW4FHuQTW4zr/D65EfhFrzkgbGiAI3BuH2KiQbmADwMETxnUDcKGhkvgRgJjjPNMvVwItOjV9V6AMXFTD7wH00M/7UBM2CeD2dfXlKbbIaR0iZAbJVx1JuIbpK+1vJ3qBFjw74yzzhvL4xIQE+zsix5p+5gEhjpTOPJ0HjNqP4rbVqLE1SihI0xf4xpET06knOlg8H5iMz5DA4rE4MbyQihW20B0yNVLX2l6lv1Bpwp4hoW122qsGaIUPQkbe6nIJ85sfM2AdwpPTxPTf3xzqhD40mLY3KlVNWEhgy5kppFU4EhaRBCxWEDG2neTv7+tnc2R4DRfbzHUnjBodkul19iiR0wECWVWInwAix5YO2KIUPgjY517mL7DT82GT3DhcpfV+PRJvWaPYCFS7S5R4zgxWURi/3NfDDdLe7q/ors/K7mT0emqkjrzlt1c2qFTN86UcktwYgE08G9pVLg3b3dhdy/dU1/GDJ7cejuXHNwS4ZBJ9/p2e/rSAZXiAkFJCo8rvkuVVCppiSoOCyQ8PiGEKCbMDJ96F7nOfkGll7xCR+dy5c9bUq2fZJjAD0ZD/dH0tPddGPfzSJhEWwepBIwS86AKi8kYawdiQ8nH6bhrxDoxES/l7zs+cLFlj2fcOWSxWGwZdnvmf3vY43zH3k/rPvzg+2PrftWoDwUBpvU13i4k7YtsJG+Ae3KyBHNBImmQALONOMdGUkfCL13jYUojZk4zO4qKilYU5BeUZs/JLrQ7HHlpJlOGRqPlKz6hUNDnmZgYHRkZ6evv77/Ye7mntaurq9njGZ8xocA/gMI/1CEAjCchwfhHgAEAd+hocxe62YwAAAAASUVORK5CYII=',
      },
      {
        code: 'ES',
        img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RDM2NjM4Rjk0N0Q4MTFFODg4MDFEOThDNjlBMkUyQzkiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RDM2NjM4RkE0N0Q4MTFFODg4MDFEOThDNjlBMkUyQzkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpEMzY2MzhGNzQ3RDgxMUU4ODgwMUQ5OEM2OUEyRTJDOSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpEMzY2MzhGODQ3RDgxMUU4ODgwMUQ5OEM2OUEyRTJDOSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PqkUfGUAAAsUSURBVHjazFp7cFTVGf+de+/efb/yXogJCY88DAR5xbYahbZCsahFLRXQDjitY3VGHWs7VqfT1raiU6ftH63VcazagvVRtcXoX4pIa00ggBDyQGMggbw22WR37z7u3sfpuZtssnkRxSXyTe7s5u7Zc7/H73uc71uypGg+DCKEIEXp72ciYwU1XjkgS9fz1sSUtdVx5fJSRS+fr2glWZqea6WwG2tjHIkM8cR/RuA7OkS+9bjF9GGDTdwX4Ll+Sun489hr+pPp6HPG7hE6lY8lxYVjC2ZmnKZvk3zr1Wn29VL8tm9L8tZKWV1JJiyYndiOtNksNNY5LXv2uiwvDPPcoPF84zKEAh1/1jhfFOMfjH5cxgSYcGMW7edqum9nMPrjLWH5DiuldmSA4oREX3dbnn3G63jUL3DdE3SVEmjEQGmCjBCf7XEiZbgJ5pxEPIWwMxS9/4/+8Kur4+pVJkBEhkgATEvj6pqbQ7E7VAK1ySIe1An06WA72c5jFjCEJGSyBUagU6xoi3/vD79UkVAvwxxQq1k4+qDPva1dFJonCpAC6jiUOEPrIyai02729Wji+ld7hg/NFfMGlcvq8t2dgfp1knzDRL+hI5qeACG3a8Yo9N2w/MNdA+EXLBRWzDGZKMRrwvGbBwS+t9liahznbRK00wVI94GtknznLwalv7AoyeFLIsYJd1VE3jTI8/0nLKZDoOcQIF3z62KJ6x4dkJ7/MplPpysi8oZWs+noKVFomyzAFAYXKlrF7/zSbp4Jh4uEGJP8rt7g7lJFraCTXJVLan1UKoHC9MSA9KKNUgcuMrLp1PFYT/BFg8cJIXgM9+zv+7bovWXViWqKi5OWIFF9a1y677mE/fEJecAIT/lefV7dLn+bzfz5tW/IT+dI6qhMpO/83FfmD7KMPZIERxLED26RfmYrOg/oMMY1xj3HkbmBEqjj9i2hh3Y97blrLJF5nFrO5nWxnVDYnc9wcSoFr+msvNChyRT7DgiIhpmnET15n9MoPute53NdXxvZ4XHqOWNRaNPa2HaLSK2zQ4UxzuuIJSwYijhxts+Bjh43DrQU40RHFrr7nAiEHYjEreAFmlx/IcjMeN1YG90+BqFNV8e3fxacqzqfZLI3JMAf8sLjDWNY4iAKLvSE2XuNGVhzwe2II9sSxZLCQYawCwOtjVdEt+2pc/xByPbQvMqFyopZYzGnYzhoR2OLB7kDp6EOmVBFghDPKIgt8uIr/+6FWijihJlZ2S7hkNUGuzUH87KZEDTzQlSUJlbmerV5wuXL5HWTDkLTat9wdZUBTu2KoeQ1pte8ED7QgMpODxT9LAJddvR22WAyhVHen0D3NSJILU0GiAsBJIPn1VXyWmFpmVIz22I5wYp/E0FeVhRllXEcanLDFVMQcSVwpJiV7bqC5ioeqhRC7rAVBxcQlK2OosCjJIt6ClwQIFWWJlYJpYVq+UwLeHZk6fyAQ0O9CJug42ubE7i0RoVuktB+3IpPBlxwDOvw9hJIeTzCBQKk+RpWX6GgvFJBIibgvTfyEAwANd+MoqQqwKJW5iqU4nlqmVDk0xadK8YPiTq6FQU2C9AXY8r+BwflbQJOiKPobAL5YQpvvhuWosXwM2FO+oAPu7PRNhTDNdX70RnoR3CIR5lsxN/M1oZFPnUxl+3R8s+1iLcROEvyQLLcyXOljVnk0kMC4hoHgX3zSsa0ohfg2Ib70H3JLRAGq0A6VmFI2QCd8MxX3KC+HChURKadIcut5XN2K3XOuIIlpFwfgb3yQQyY16NoEUtUDNRHi3T0rtMw8A0N7xcj6QNqSy+E//TB278QloTXaKaAd/IQFmxGMO9hBLQ8ZgE9owIYvAvnzhgMQg2Aq/sI5ne2outZATk9zCF5hnWWrIYUG5bL/bA7BNjXFCPaHQEZ5sE5OBCWM6TXWHkeaIKLi8NllaHF0xpKGSBFJQkuEiPhaeM+Yz50hIO0hzFz8kMoUQnBJpb5mMPyDh1miw6fJ4YBu4iXWUb273kdulsBLyUgWkSGNoLoUeYvoUHYho7D9WYMiWY+uW/GCjvGOzc4zPVN678sxvOFOtOoiviK2zHgWgQxR0dkJYVzUIV4UERBQxz/dFWh6SoHznS9C0eYJbONzDEKzdBtPPhaGRGpAkO1O9HnZCc/klkIhSLckNDZLXwyXSSiKmBlfpt3L49IoB1r2jqRXcWhqVaDxHBQEg9B7NERMruTWP+ILMeShueBrpchczQZXp07daxqO4H/uk3wrtdhqaDQ5cwJ0NkjfMx9ekZonRZC7Nwz7CcQH6Owv9+FU1dWwrNDZfUQgxETzG7SIbooNlsaQJujKA+0QC+QUCoPY6k5CI8UhrBMxP9uLMGCUwHYnogiyiBJMtjfON0ttHHHTprqZ4KQw0nRysqBUzfdhoDDl+ytprdljEJhnh7B9sX7scLVDpVx98k8AbEI81QDLTrbZGEV6nfcjX2rskHtRqmdOQGaPxUbufpj4j5Kp8YFVupDZNoq30ZZ9jwMB86ycoL5hTCxLqBGfcRyhShwyGXb2FlISHgoEkZXwJBYagHteg/Lb5TgqGaROUMQMng+2GR+N+nEze2mw9OXoBQftVjR1/4K9GgjTpw2o9BBEetnzBk9F2YmgR1uguQyxAUrrFwMpUOsOh1mSW4BixKshjrV3ght8CVIIRaFoiyDZ6goau0QD/uHhO5kHnjzPevfL12krJzadaV4q/VbaD5bkjRRDz2Bh66tYxGH+epBM2ycByfLKzAg2aGV+rCsrwODIWYpdxyX36HhneZqvN213jiAoDE0gJKif2FRoZ8F8C9eD719wLbHgIJgdCT2MgHuuS382ymnMobXmoXN8Nr7YBMTWFwQgMlNcOVWVrxtSDAMmtE7bEawW4Mvl8C3Glh+SRxZXhXWbKBE7sH6pfsRUwQUZQ3Dbo6PYO4Lkpwgsb377S8kO3XGhMao2R++O/inWzZFfzR5sa7Tsc71yMGGjNRkDF4qq4d0dkjQdJLEO2F1hkkYcSfDf43ztq6nvpfeXf5i9PJbjj8/+pT3ruRAJDViyvfo8+oeGZjSVpl4riUT2ieEYEpdkH76IpPGQpk4mRltlRt+XVDmD/LdhgBjtVAfu/HkPc5fPcBFH59tNna+n2fCf5/hnI/4Ocb86G4jja3R7hyvU9MrfaH6yjmcBXzOwceRrUXZNRohyoTmbqorrXFEuS/XsUXiSOhiYz7CkfADPs/3VALlnN3p0wL/8U9yHLdqyRh0cRCLA9qDBe7tp0X+5FgzevTis93OKfOBDhPfNsRz/qtjyrUXgwC/yXPd/abTsptMGbmSqQOO1EizyWw61C9wPbUxZeOXNegwNP9IvuvOVzzWp8YicFonOem3kwVIXcliyWxqbBOFY7WxxEaWTM1zyXyUI9JPfZ6tdS7L7pkimBGJuLH4RsZnxen0jk184yafZ1WLKByZK+bbzMJHWy/x1rzjML8+W2t8xAKTWnMpC6RegzwXeM1h+avMIb5cVr9qDKYvBOMyIbEns+2/fDjftcOYTiZ1PEvymHFKmTp9p/5n1YLWaDEdeMNpec6AY1lCW5apab3xUwOG86fvL3Bted9hrtMJ0SYrc8bkmEpkmMYCRubnZsifXk3PuS4i37opIm+rlNUV5/NjjxazcNjA+F6n5W8s6g1M3wMl0waZVL9yrBY6l8SzaSGH6vk1CWXtUkWtKdW0ikJNK8mieq4xmEs5ZIDj/Gd5vuNTgW85bjLVN5hN+wa5kYbC2P6jTNG0KJNkOs2JJ/dZ/y/AACSFqq36itdoAAAAAElFTkSuQmCC',
      },
    ];

    // var tels = Drupal.settings.altium_common_menus.regions_phone;

    getGeo('https://www.altium.com/geoip_region.php', function (resp) {
      var countryCode = resp && resp.code ? resp.code : '';
      var current;
      var def = 'US';

      for(var i = 0; i < tels.length; i++) {

        if(countryCode == 'HK') {
          if(tels[i].code == 'CN') {
            current = tels[i];
            break;
          }
        } else if(countryCode == tels[i].code) {
          current = tels[i];
          break;
        }

        if(def == tels[i].code) {
          def = tels[i];
        }
      }

      if(!current) {
        current = def;
      }

      current.img = getImg(current.code);

      var content = '<div class="block-tel">' +
        '<span class="block-tel__ico"><img src="' + current.img + '" alt=""></span>' +
        '<a class="block-tel__tel" href="tel:' + current.tel.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()\sA-Za-z]/g, '') + '">' + current.tel + '</a>' +
        '</div>'

      if(position == 'after') {
        $elm.after(content);
      } else {
        $elm.before(content);
      }


    });

    function getImg(code) {
      for(var i = 0; i < imgs.length; i++) {
        if(code == imgs[i].code) {
          return imgs[i].img;
        }
      }
    }

  }

  window.getGeo = function(url, clb) {
    if(!clb) {clb = function() {console.warn('Use callback!')}}
    var session = sessionStorage.getItem('geoip_region');
    if(session) {
      return clb(JSON.parse(session));
    }

    var request = new XMLHttpRequest();
    request.open('GET', url, true);

    request.onload = function() {
      if (request.status >= 200 && request.status < 400) {
        var data = JSON.parse(request.responseText);
        sessionStorage.setItem('geoip_region', JSON.stringify(data));
        return clb(data);
      } else {
        console.warn('We reached our target server, but it returned an error');
      }
    };

    request.onerror = function() {
      console.warn('There was a connection error of some sort');
    };

    request.send();
  };

})(jQuery);
