/*
var $ = jQuery;

    var userCookieNames = ["ALU_SID_2","ALU_UID_2","ALU_PID_2","DRU_email","DRU_company","DRU_firstname","DRU_lastname","DRU_user","DRU_icon"];

    function getRecord(records,recordName){
        var result = null;
        $.each(records,function(index,record){
            if(record.Name == recordName){
                result = record.Value;
            }
        });
        return result;
    }


    function setUserCookies(userAccount){
        var currentDate = new Date();
        var options = {
            expires : new Date().setTime(currentDate.getTime() + 3600000000),
            domain : (window.location.hostname.indexOf("altium.com.cn") == -1) ? ".altium.com" : ".altium.com.cn",
            path : "/"
        };
        Cookies.set("ALU_SID_2",userAccount.SessionID,options);
        Cookies.set("ALU_UID_2",userAccount.Email,options);
        Cookies.set("DRU_email",userAccount.Email,options);
        Cookies.set("DRU_company",userAccount.Organization,options);
        Cookies.set("DRU_firstname",userAccount.FirstName,options);
        Cookies.set("DRU_lastname",userAccount.LastName,options);
        Cookies.set("DRU_user",userAccount.FullName,options);
        Cookies.set("DRU_known",'1',options);
        var profilePicture = getRecord(userAccount.Parameters.Records,"ProfilePicture");
        if(profilePicture){
            var imageName = (profilePicture.indexOf("cus_") == -1) ?
                'https://s3.amazonaws.com/AltiumEcosys1-1/ALU_Apps/avatars/small/' + profilePicture + ".png" :
                'https://s3.amazonaws.com/AltiumEcosys1-1/ALU_Apps/profilepics/48/' + profilePicture + ".jpg";
            Cookies.set("DRU_icon",imageName,options);

        } else {
			Cookies.set("DRU_icon",'/resources/images/unknown_avatar.png',options);
		}
    }



    function unsetUserCookies(){
        for(var i = 0; i < userCookieNames.length; i++){
            var currentDate = new Date();
            var options = {
                expires : new Date().setTime(currentDate.getTime() - 3600),
                domain : "." + document.location.hostname,
                path : "/"
            };
            Cookies.expire(userCookieNames[i],options);
        }
    }


//    $('a[data-action="logout"]').bind("click",function(){
//        unsetUserCookies();
//        //document.location.reload(true);
//        //return false;
//    })

*/